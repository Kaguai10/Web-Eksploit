CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  password TEXT
);

INSERT INTO users (username, password) VALUES ('admin', 'admin123');
INSERT INTO users (username, password) VALUES ('user', 'user123');

CREATE TABLE gallery (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  foto TEXT,
  cerita TEXT,
  secret_key TEXT
);

INSERT INTO gallery (foto, cerita, secret_key) VALUES 
('foto1.png', 'Rambu penyeberangan di jalan malam hari.', 'KEY{jalan_malam_rahasia}'),
('foto2.png', 'Seorang fotografer sedang mengambil gambar.', 'KEY{kamera_tangan_rahasia}'),
('foto3.png', 'Tugu Jogja di pagi hari yang indah.', 'KEY{tugu_jogja_spesial}'),
('foto4.png', 'Saung kecil di tengah sawah saat senja.', 'KEY{sawah_senja_hidden}'),
('foto5.png', 'Potret seseorang tersenyum dengan sweater putih.', 'KEY{senyum_putih_cantik}'),
('foto6.png', 'Selfie cerah di dalam mobil.', 'KEY{mobil_senyum_secret}'),
('foto7.png', 'Pose ceria dengan baju putih sederhana.', 'Flag{sqli_asikkk_bangetkan??}'),
('foto8.png', 'Mata bercahaya merah biru dari karakter anime.', 'KEY{kuat_danbersinar}');

<?php
session_start();
$db = new PDO('sqlite:/var/www/html/database.sqlite');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    $sql = "SELECT * FROM users WHERE username='$u' AND password='$p'";
    $res = $db->query($sql);

    if ($res && $res->fetch()) {
        $_SESSION['user'] = $u;
        header("Location: gallery.php");
        exit;
    } else {
        $error = "Login gagal, coba lagi yaa 💔";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Cute</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-pink-100 flex items-center justify-center h-screen font-sans">
  <div class="bg-white p-8 rounded-2xl shadow-lg w-80 text-center">
    <h2 class="text-2xl font-bold text-pink-600 mb-4">💖 Login Yuk 💖</h2>
    <form method="post" class="space-y-3">
      <input type="text" name="username" placeholder="Username"
        class="w-full p-2 border rounded-xl focus:outline-pink-400" required>
      <input type="password" name="password" placeholder="Password"
        class="w-full p-2 border rounded-xl focus:outline-pink-400" required>
      <button type="submit"
        class="w-full bg-pink-400 hover:bg-pink-500 text-white py-2 rounded-xl transition">
        Masuk ✨
      </button>
    </form>
    <?php if (!empty($error)): ?>
      <p class="text-red-500 mt-3"><?= $error ?></p>
    <?php endif; ?>
  </div>
</body>
</html>
